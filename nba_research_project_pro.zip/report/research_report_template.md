
# Research Report Template

## Abstract
This study investigates how NBA offensive strategy has evolved from 2000 to 2025, focusing on three-point shooting and team success.

## Introduction
The NBA has undergone a dramatic strategic shift toward perimeter-oriented offenses.

## Methods
Data were collected from publicly available NBA statistics sources.

Analyses:
- Trend analysis
- Correlation analysis
- Linear regression
- Feature importance modeling

## Results
Insert figures and discuss findings.

### Figure 1
Three-point attempts increased substantially from 2000–2025.

### Figure 2
Relationship between three-point volume and team wins.

### Figure 3
Correlation heatmap.

## Discussion
Discuss whether volume or efficiency matters more.

## Limitations
- Team-level data only
- Correlation does not imply causation

## Future Work
- Player-level analysis
- Shot location analysis
- Machine learning classification
