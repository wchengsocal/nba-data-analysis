
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor

df = pd.read_csv("data/nba_team_stats.csv")

# 1. League trends
league = df.groupby("Season").agg({
    "ThreePA":"mean",
    "ThreePPercent":"mean",
    "OffensiveRating":"mean"
}).reset_index()

# Trend plot
plt.figure(figsize=(8,5))
plt.plot(league["Season"], league["ThreePA"])
plt.title("Average Three Point Attempts by Season")
plt.tight_layout()
plt.savefig("figures/three_point_trend.png")

# Correlation matrix
corr = df[[
    "Wins",
    "ThreePA",
    "ThreePPercent",
    "OffensiveRating",
    "DefensiveRating",
    "Rebounds"
]].corr()

print(corr)

# Linear regression
features = [
    "ThreePA",
    "ThreePPercent",
    "OffensiveRating",
    "DefensiveRating",
    "Rebounds"
]

X = df[features]
y = df["Wins"]

model = LinearRegression()
model.fit(X,y)

print("R2:", model.score(X,y))

# Random forest feature importance
rf = RandomForestRegressor(
    n_estimators=200,
    random_state=42
)

rf.fit(X,y)

importance = pd.DataFrame({
    "Feature":features,
    "Importance":rf.feature_importances_
}).sort_values("Importance", ascending=False)

print(importance)
